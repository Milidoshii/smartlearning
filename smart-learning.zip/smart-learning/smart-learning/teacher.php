<div class="row g-3">
    <div class="col-12">
        <h1>Teacher Dashboard</h1>
    </div>
    <div class="col-md-3">
        <a href="post_and_view_question.php" class="btn btn-primary w-100">Discussion Board</a>
    </div>
    <div class="col-md-3">
        <a href="view_post_question.php" class="btn btn-success w-100">Create Quiz</a>
    </div>
    <div class="col-md-3">
        <a href="teacher_view_answer.php" class="btn btn-light w-100">View Answer</a>
    </div>
    <div class="col-md-3">
        <a href="folder.php" class="btn btn-info w-100">Teacher Folder</a>
    </div>
</div>