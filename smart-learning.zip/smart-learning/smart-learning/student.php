<div class="row g-3">
    <div class="col-12">
        <h1>Student Dashboard</h1>
    </div>
    <div class="col-md-3">
        <a href="post_and_view_question.php" class="btn btn-primary w-100">Discussion Board</a>
    </div>
    <div class="col-md-3">
        <a href="view_question.php" class="btn btn-success w-100">Answer Quiz</a>
    </div>
    <div class="col-md-3">
        <a href="view_feedback.php" class="btn btn-dark w-100">View Feedback</a>
    </div>
    <div class="col-md-3">
        <a href="folder.php" class="btn btn-info w-100">Student Folder</a>
    </div>
</div>