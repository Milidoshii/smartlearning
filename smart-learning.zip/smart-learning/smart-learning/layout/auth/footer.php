</div>
<!-- content-wrapper ends -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- plugins:js -->
<script src="assets2/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="assets2/vendors/chart.js/Chart.min.js"></script>
<script src="assets2/js/jquery.cookie.js" type="text/javascript"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="assets2/js/off-canvas.js"></script>
<script src="assets2/js/hoverable-collapse.js"></script>
<script src="assets2/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="assets2/js/dashboard.js"></script>
<script src="assets2/js/todolist.js"></script>
<script src="assets2/vendors/ckeditor/ckeditor.js"></script>
<!-- End custom js for this page -->
<?php include('components/script.php'); ?>
</body>

</html>